package com.demo_rabitmq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoRabitmqApplicationTests {

	@Test
	void contextLoads() {
	}

}
