package com.demo_rabitmq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoRabitmqApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoRabitmqApplication.class, args);
	}

}
