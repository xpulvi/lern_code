package com.neo4j_film_tutorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Neo4jFilmTutorialApplicationTests {

	@Test
	void contextLoads() {
	}

}
